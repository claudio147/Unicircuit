<?php

?>
<!DOCTYPE html>
<html lang="de">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable= no">
	<meta name="apple-mobile-web-app-capable" content="yes" />

	<title>Unicircuit</title>

	

       
</head>
<body>

<a href="imageupload.php">Bildverwaltung</a><br/><br/><br/>
<a href="textChange.php">Textverwaltung</a><br/><br/><br/>
<a href="../../productsite/public/index.php" id="enableInlineEditor">Inline Editor</a>


<script src="../../productsite/public/js/jquery-1.11.1.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>